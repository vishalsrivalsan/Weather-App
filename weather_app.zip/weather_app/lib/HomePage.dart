import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:weather_app/Containers.dart';
import 'package:weather_app/fetchWeather.dart';
import 'package:weather_app/fetchLocation.dart';
//import 'urlHandling.dart';

class HomePage extends StatefulWidget {
  var weatherData;

  HomePage({this.weatherData});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

   late TextEditingController searchText;
  Weather weather=new Weather();
  double latitude=0;
  double longitude=0;
  int temperature=0;
  int feelTemperature=0;
  String weatherMainDesc="";
  String weatherDesc="";
  String cityName="";
  int humidity=0;



  @override
  void initState() {
    // TODO: implement initState
    searchText=new TextEditingController();
    super.initState();
    updateUI(widget.weatherData);
    // Locate().getLocation();-
  }

  updateUI(var weatherData){
    print('Updating UI');
    setState(() {
      if(weatherData==null){
        latitude=0;
        longitude=0;
        temperature=0;
        feelTemperature=0;
        weatherMainDesc="";
        weatherDesc="";
        cityName="";
        humidity=0;
      }
      else{
        latitude=weatherData[0];
        longitude=weatherData[1];
        print('$latitude $longitude');
        temperature=weatherData[2];
        feelTemperature=weatherData[3];
        weatherMainDesc=weatherData[4];
        weatherDesc=weatherData[5];
        cityName=weatherData[6];
        humidity=weatherData[7];
      }
    });
  }
  /*getByCityName(String cityName){
    var weatherData= Weather().getWeatherByCity(cityName);
    updateUI(weatherData);
  }*/
@override
  /*Widget build(BuildContext context){
    return Scaffold(
      body: GradientContainer(Colors.blue,buildHomeView(context)),
    );
  }*/

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
              // decoration: BoxDecoration(
              //         gradient: LinearGradient(
              //           begin: Alignment.topRight,
              //           end: Alignment.bottomLeft,
              //           stops: [0,1.0],
              //           colors: [Colors.blue.shade800,Colors.blue.shade400],
              //         )
              // ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                children: [
                  SizedBox( height: 40 ),
                   SearchContainer(update:updateUI),

                  SizedBox( height: 50 ),
                  LocationContainer(cityName, latitude, longitude),

                  SizedBox( height: 60 ),
                  TemperatureContainer(temperature, feelTemperature),

                  SizedBox(height: 50,),
                  Text('$weatherMainDesc',style: TextStyle(color: Colors.white,fontSize: 40,fontWeight: FontWeight.w300)),
                ],
              ),
            ),
          ],
        ),
      )
    );
    //);
  }
}

