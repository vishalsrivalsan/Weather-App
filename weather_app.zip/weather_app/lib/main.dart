import 'package:flutter/material.dart';
import 'package:weather_app/fetchWeather.dart';
import 'package:weather_app/fetchLocation.dart';
import 'package:weather_app/HomePage.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(),
      home: LoadingPage(),
    );
  }
}

class LoadingPage extends StatefulWidget {
  @override
  _LoadingPageState createState() => _LoadingPageState();
}

class _LoadingPageState extends State<LoadingPage> {

var weatherData;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getWeatherData();
  }

void getWeatherData() async{
  Weather weather=new Weather();

  weatherData= await weather.getWeatherByCity('coimbatore');
    Navigator.push(context, new MaterialPageRoute(builder: (context) => HomePage(weatherData: weatherData,),));
}

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        title: Text("Weather"),
      ),
      body: Center(
        child: SpinKitRotatingCircle(
          color: Colors.white,
          size: 50.0,
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}