import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:weather_app/HomePage.dart';
import 'package:weather_app/fetchWeather.dart';

class GradientContainer extends StatelessWidget {
	Widget child;
	final MaterialColor color;
	GradientContainer(this.color,this.child);

  @override
  Widget build(BuildContext context) {
    return Container(
	    decoration: BoxDecoration(
		    gradient: LinearGradient(
			    begin: Alignment.topRight,
			    end: Alignment.bottomLeft,
			    stops: [0,1.0],
			    colors: [color.shade800,color.shade400],
		    )
	    ),
	    child: child,
    );
  }
}



class SearchContainer extends StatefulWidget {
	final ValueChanged<List> update;
	SearchContainer({required this.update});
  @override
  _SearchContainerState createState() => _SearchContainerState();
}

class _SearchContainerState extends State<SearchContainer> {
  TextEditingController searchText=new TextEditingController();
	//final ValueChanged<List> update;
	//_SearchContainerState({required this.update});
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //cityNameController=new TextEditingController();
  }
  getByCityName(String cityName) async{

	  var weatherData= await Weather().getWeatherByCity(cityName);
	  widget.update(weatherData);
	  //print('${new HomePageState().temperature}');

  }

	@override
  Widget build(BuildContext context) {
    return Container(
	   /* margin: EdgeInsets.only(left: 20, top:20, right:20, bottom:50),*/
	    padding: EdgeInsets.only(left: 5,top: 5,right: 20,bottom: 0),
	    height: 50,
	    width: 200,
	    decoration: BoxDecoration(
		    color: Colors.white,
		    borderRadius: BorderRadius.only(
			    topLeft: Radius.circular(3),
			    topRight: Radius.circular(3),
			    bottomLeft: Radius.circular(3),
			    bottomRight: Radius.circular(3),
		    ),
		    boxShadow: [
		    	BoxShadow(
				    color: Colors.black.withOpacity(0.3),
				    spreadRadius: 3,
				    blurRadius: 5,
				    offset: Offset(0, 3),
			    )
		    ],
	    ),
	    child: Row(
		    //mainAxisSize: MainAxisSize.max,
		   // mainAxisAlignment: MainAxisAlignment.start,
		    children: [
		    	IconButton(onPressed: (){getByCityName(searchText.text);}, icon: Icon(Icons.search)),
			    SizedBox(width: 10,),
			    Expanded(child: TextField(
				    controller: searchText,
				    decoration: InputDecoration.collapsed(hintText: "Enter City"),
				   // onSubmitted: homepage.getByCityName(searchText.text),
			    ))
		    ],
	    ),
    );
  }
}

class LocationContainer extends StatefulWidget {
  LocationContainer(this.cityName,this.latitude,this.longitude);
  final String cityName;
  final double latitude,longitude;
  @override
  _LocationContainerState createState() => _LocationContainerState();
}

class _LocationContainerState extends State<LocationContainer> {
	String cityName='';
	double latitude=0,longitude=0;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setScreen(widget.cityName,widget.latitude,widget.longitude);
  }
  void setScreen(String cityName,double latitude,double longitude){
  	this.cityName=cityName;
  	this.latitude=latitude;
  	this.longitude=longitude;
  }
	@override
  Widget build(BuildContext context) {
    return Container(
	    child: Center(
		    child: Column(
			    mainAxisAlignment: MainAxisAlignment.center,
			    children: [
			    	Text('${cityName.toUpperCase()}',style: TextStyle(color: Colors.white,fontSize: 38,fontWeight: FontWeight.w300),),
				    SizedBox(height: 5,),
				    Row(
					    mainAxisAlignment: MainAxisAlignment.center,
					   children: [
						   Icon(Icons.location_on,color: Colors.white,),
						   SizedBox(width: 5,),
						   Text('${latitude.toStringAsFixed(2)} ,',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.w300),),
						   Text(' ${longitude.toStringAsFixed(2)}',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.w300),),
					   ],
				    )
			    ],
		    ),
	    ),
    );
  }
}

class TemperatureContainer extends StatefulWidget {
	TemperatureContainer(this.temperature,this.feelTemperature);
	final int temperature,feelTemperature;
  @override
  _TemperatureContainerState createState() => _TemperatureContainerState();
}

class _TemperatureContainerState extends State<TemperatureContainer> {
	int temperature=0,feelTemperature=0;
	@override
  void initState() {
    // TODO: implement initState
    super.initState();
    setScreen(widget.temperature,widget.feelTemperature);
  }
	void setScreen(int temperature,int feelTemperature){
		this.temperature=temperature;
		this.feelTemperature=feelTemperature;
	}
  @override
  Widget build(BuildContext context) {
    return Container(
	    child: Center(
		    child: Row(
			    mainAxisAlignment: MainAxisAlignment.spaceAround,
			    children: [
				    Column(
					    mainAxisAlignment: MainAxisAlignment.center,
				      children: [
				        Text( '${temperature.toString()}°ᶜ' , style: TextStyle(color: Colors.white,fontSize: 70,fontWeight: FontWeight.w300) ),
					    SizedBox(height: 10),
					    Text( 'Feels like ${feelTemperature.toString()}°ᶜ' ,  style: TextStyle(color: Colors.white,fontSize: 25,fontWeight: FontWeight.w300) ),
				      ],
				    ),
				    SizedBox(
					    width: 20,
				    ),
				    Icon(Icons.wb_cloudy,color: Colors.white,),
			    ],
		    ),
	    ),
    );
  }
}

