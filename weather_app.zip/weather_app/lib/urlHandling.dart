import 'dart:convert';
import 'package:http/http.dart' as http;

class Network{
	Network(this.link);
	var link;
	Future<dynamic> getData() async{
			var parsedlink = Uri.parse('$link');
			var response=await http.get(parsedlink);
			//print(response.body);
			//print(jsonDecode(response.body));
			if(response.statusCode==200){
				return jsonDecode(response.body);
			}
			else{
				print(response.statusCode);
			}
	}
}