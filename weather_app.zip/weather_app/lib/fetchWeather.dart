
import 'package:weather_app/fetchLocation.dart';
import 'package:weather_app/urlHandling.dart';

const apiKey='5acc95279bfec56dfeedd1cfae91d343';
const weatherURL='http://api.openweathermap.org/data/2.5/weather';
class Weather{
	String url="";
	double latitude=0.0;
	double longitude=0.0;
	int temperature=0;
	int feelTemperature=0;
	String weatherMainDesc="";
	String weatherDesc="";
	String cityName="";
	int humidity=0;

	Future<List> getWeatherByLocation() async{

		Locate location=Locate();
		latitude=location.latitude;
		longitude=location.longitude;
		//print('$latitude $longitude');
		url='$weatherURL?lat=$latitude&lon=$longitude&appid=$apiKey&units=metric';
		Network network=new Network(url);
		var weatherData=await network.getData();

		temperature=weatherData['main']['temp'].toInt();
		feelTemperature=weatherData['main']['feels_like'].toInt();
		weatherMainDesc=weatherData['weather'][0]['main'];
		weatherDesc=weatherData['weather'][0]['description'];
		cityName=weatherData['name'];
		humidity=weatherData['main']['humidity'];

		return [latitude,longitude,temperature,feelTemperature,weatherMainDesc,weatherDesc ,cityName,humidity];
	}

	Future<List> getWeatherByCity(String name) async{

		url='$weatherURL?q=$name&appid=$apiKey&units=metric';
		Network network=new Network(url);
		var weatherData=await network.getData();

		//print(weatherData);
		latitude=weatherData['coord']['lat'].toDouble();
		longitude=weatherData['coord']['lon'].toDouble();
		temperature=weatherData['main']['temp'].toInt();
		feelTemperature=weatherData['main']['feels_like'].toInt();
		weatherMainDesc=weatherData['weather'][0]['main'];
		weatherDesc=weatherData['weather'][0]['description'];
		cityName=weatherData['name'];
		humidity=weatherData['main']['humidity'];

		return [latitude,longitude,temperature,feelTemperature,weatherMainDesc,weatherDesc,cityName,humidity];
	}
}